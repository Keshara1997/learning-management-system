<?php

class Services_Twilio_Rest_Application
    extends Services_Twilio_InstanceResource
{
}
