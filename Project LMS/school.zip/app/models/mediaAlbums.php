<?php
class mediaAlbums extends Eloquent {
	public $timestamps = false;
	protected $table = 'mediaAlbums';
}