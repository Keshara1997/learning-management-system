<?php
class classSchedule extends Eloquent {
	public $timestamps = false;
	protected $table = 'classSchedule';
}