<?php
class payments extends Eloquent {
	public $timestamps = false;
	protected $table = 'payments';
}