<?php
class messages extends Eloquent {
	public $timestamps = false;
	protected $table = 'messages';
}