<?php
class gradeLevels extends Eloquent {
	public $timestamps = false;
	protected $table = 'gradeLevels';
}