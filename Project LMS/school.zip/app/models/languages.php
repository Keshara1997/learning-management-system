<?php
class languages extends Eloquent {
	public $timestamps = false;
	protected $table = 'languages';
}